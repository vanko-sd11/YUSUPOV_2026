using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    [SerializeField] private GameObject _mainMenuPanel;
    [SerializeField] private GameObject _mainSettingsPanel;

    public void StartGame()
    {
        SceneManager.LoadScene("GameScene");
    }
    public void MenuPanel()
    {
        _mainMenuPanel.SetActive(true);
        _mainSettingsPanel.SetActive(false);
    }
    public void SettingsPanel()
    {
        _mainSettingsPanel.SetActive(true);
        _mainMenuPanel.SetActive(false);
    }
    public void ExitGame()
    {
        Application.Quit();
    }
}
